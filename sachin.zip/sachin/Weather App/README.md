# Day #10

### Weather App
In this tutorial ([Open in Youtube](https://youtu.be/iILFBGm_I9M)),  I am gonna showing to you how to code a weather app with javascript. in this tutorial also we use a weather api and we get data from api❗️

## Warning
You need to get your own api key (in video we showed how!) and replace it in index.js file on line 9 :

```javascript
const APIKey = 'Your Api Key';
```


# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
